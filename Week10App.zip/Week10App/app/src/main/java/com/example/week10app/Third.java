package com.example.week10app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Third extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        databaseHelper = new DatabaseHelper(this);

        EditText id = findViewById(R.id.edTextId);
        Button btnDel = findViewById(R.id.btnDelete);

        btnDel.setOnClickListener(new View.OnClickListener() {
            int intId; boolean isDeleted;
            @Override

            public void onClick(View view) {
                intId = Integer.parseInt(id.getText().toString());
                isDeleted= databaseHelper.deleteRec(intId);
                if(isDeleted){
                    Toast.makeText(Third.this, "a record is deleted",
                            Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(Third.this, "a record is not deleted",
                            Toast.LENGTH_LONG).show();
                }
                }

        });
    }
}