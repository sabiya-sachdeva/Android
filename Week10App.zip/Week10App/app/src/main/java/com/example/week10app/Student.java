package com.example.week10app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Student extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        databaseHelper = new DatabaseHelper(this);

        EditText name = findViewById(R.id.edTextName);
        EditText sNum = findViewById(R.id.edTextSNum);
        EditText cell = findViewById(R.id.edTextCell);
        EditText cId = findViewById(R.id.edTextCId);
        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnView = findViewById(R.id.btnView);
        Button btnThird = findViewById(R.id.btnDelUpdate);

        TextView textView = findViewById(R.id.txtOutput);

        btnThird.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Student.this,Third.class));
            }
        });

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor cursor = databaseHelper.viewData();
                StringBuilder str = new StringBuilder();
                if(cursor.getCount()>0){
                    while(cursor.moveToNext()){
                        str.append(" Id : " + cursor.getString(0));
                        str.append(" Name : " + cursor.getString(1));
                        str.append(" SNum : " + cursor.getString(2));
                        str.append(" cell : " + cursor.getString(3));
                        str.append(" CId : " + cursor.getString(4));
                        str.append("\n");
                    }
                    textView.setText(str);
                }
                else{
                    Toast.makeText(Student.this, "nothing to read",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        //clicking add a record method will insert data to the table
        btnAdd.setOnClickListener(new View.OnClickListener() {
            boolean isInserted;
            @Override
            public void onClick(View view) {
                isInserted= databaseHelper.addData(name.getText().toString(),
                        sNum.getText().toString(),cell.getText().toString(),
                        cId.getText().toString());
                if(isInserted){
                    Toast.makeText(Student.this, "Data added",
                            Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Student.this, "Data not added",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}