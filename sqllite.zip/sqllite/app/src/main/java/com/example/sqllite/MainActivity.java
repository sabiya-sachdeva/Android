package com.example.sqllite;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseHelper = new DatabaseHelper(this);
        EditText fname=findViewById(R.id.idfname);
        EditText lname=findViewById(R.id.idlname);
        EditText no=findViewById(R.id.idnumber);
        Button btnadd=findViewById(R.id.btnadd);
        Button btndelete=findViewById(R.id.btndelete);
        Button btnview=findViewById(R.id.btnview);
        TextView textView=findViewById(R.id.textView);
        btnview.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Cursor cursor =databaseHelper.viewRec();
                StringBuilder str=new StringBuilder();
                if(cursor.getCount()>0)
                {
                    while (cursor.moveToNext())
                    {
                        str.append("FName: "+cursor.getString(0)+"\n");
                        str.append("LName: "+cursor.getString(1)+"\n");
                        str.append("Phone Number: "+cursor.getString(2)+"\n");
                        str.append("\n");
                    }
                    textView.setText(str);
                }
                else
                {
                    Toast.makeText(MainActivity.this,"record not found",Toast.LENGTH_SHORT).show();
                }
            }
        });
        btndelete.setOnClickListener(new View.OnClickListener() {
            boolean isdeleted;
            @Override
            public void onClick(View v) {
                isdeleted=databaseHelper.deletedata(fname.getText().toString());
                if(isdeleted)
                {
                    Toast.makeText(MainActivity.this,"Data deleted",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Data not deleted",Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnadd.setOnClickListener(new View.OnClickListener() {
            boolean isInserted;
            @Override
            public void onClick(View view) {
                isInserted=databaseHelper.addData(fname.getText().toString(),lname.getText().toString(),no.getText().toString());
                if(isInserted)
                {
                    Toast.makeText(MainActivity.this,"Data added",Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(MainActivity.this,"Data not added",Toast.LENGTH_SHORT).show();
            }
        });
    }
}