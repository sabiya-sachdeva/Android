package com.example.sqllite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class DatabaseHelper extends SQLiteOpenHelper {

    final static String DATABASE_NAME="Information.db";
    final static int DATABASE_VERSION=1;
    final static String TABLE1_NAME="Student_table";
    final static String T1COL1="Fname";
    final static String T1COL2="Lname";
    final static String T1COl3="number";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
String query=" CREATE TABLE " + TABLE1_NAME + "(" + T1COL1 +" TEXT," + T1COL2 + " TEXT," + T1COl3 +" INTEGER PRIMARY KEY )";
sqLiteDatabase.execSQL(query );
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE1_NAME);
    }

    public boolean addData(String Fname,String Lname,String cell)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(T1COL1,Fname);
        values.put(T1COL2,Lname);
        values.put(T1COl3,cell);
        long l=sqLiteDatabase.insert(TABLE1_NAME,null,values);
        if(l>0)
            return true;
        else
            return false;
    }

    public boolean deletedata(String fname)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
       int r=sqLiteDatabase.delete(TABLE1_NAME,"fname=?",new String[]{fname});
if(r>0)
{
    return true;
}
else
    return false;

    }
    public Cursor viewRec()
    {
        SQLiteDatabase sqLiteDatabase=this.getReadableDatabase();
        String query="select * from "+TABLE1_NAME;
  Cursor res=sqLiteDatabase.rawQuery(query,null);
  return res;
    }
}
